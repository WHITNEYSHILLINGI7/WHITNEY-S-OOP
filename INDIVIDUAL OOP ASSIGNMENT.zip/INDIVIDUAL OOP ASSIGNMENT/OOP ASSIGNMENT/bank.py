class BankAccount:
    interest_rate = 0.05 # Class variable

    def __init__(self, account_holder):
        self.account_holder = account_holder
        self.balance = 0 # initial balance set to zero 
    
    def deposit(self, amount):
        print(f"Deposit Shs{amount:.2f} into {self.account_holder}'s account.")

    def withdraw(self, amount):  
        if amount > self.balance:
            print("Insufficient funds.")
        else:
            self.balance -= amount
            print(f"Withdrew Shs{amount:.2f} interest to {self.account_holder}'s account.")  
    def apply_interest(self): 
        interest = self.balance * BankAccount.interest_rate
        self.balance += interest
        print(f"Applied Shs{interest:.2f} interest to {self.account_holder}'s account.")
    def display_account_info(self):
        print(f"Account Holder: {self.account_holder}")
        print(f"Balance: Shs{self.balance:.2f}")

#creating two instances of BankAccount
account1 = BankAccount("MUGISHA TEVIN")
account2 = BankAccount("NIMUSIIMA BRENDA")

#Here are a few deposits and withdraws
account1.deposit(10000)
account1.withdraw(5000)
account2.deposit(20000)
account2.withdraw(5000)

#Apply interest
account1.apply_interest()
account2.apply_interest()

#Display of account information for each account
print("\nAccount 1 Information:")
account1.display_account_info()
print("\nAccount 2 Information:")
account2.display_account_info()
