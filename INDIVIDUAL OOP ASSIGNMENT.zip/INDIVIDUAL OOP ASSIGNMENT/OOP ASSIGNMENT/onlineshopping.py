class Product:
    def __init__(self, product_name, price, quantity_in_stock): #class variable
        self.product_name = product_name
        self.price = price
        self.quantity_in_stock = quantity_in_stock

    def display_product_info(self):
        print(f"Product Name: {self.product_name}")
        print(f"Price: {self.price}")
        print(f"Quantity in stock: {self.quantity_in_stock}")   

class ShoppingCart:
    total_carts = 0

    def __init__(self):
        ShoppingCart.total_carts += 1
        self.items = []

    def add_to_cart(self, product, quantity):
        if quantity < product.quantity_in_stock:
            self.items.append((product, quantity))
            product.quantity_in_stock -= quantity
            print(f"Added {quantity} {product.product_name}(s) to cart")
        else:
            print("Insufficient quantity in stock.")

    def remove_from_cart(self, product):
        for item in self.items:
            if item[0] == product:
                self.items.remove(item)
                product.quantity_in_stock += item[1]
                print(f"{item[1]} x {item[0].product_name} = Shs{item[0].price * item[1]:.2f}")
    def calculate_total(self):
        total = sum(item[0].price * item[1] for item in self.items)

#creating product objects
product1 = Product("School bag", 5000, 5)
product2 = Product("Black shoes", 10000, 2)
product3 = Product("Bedsheets", 15000, 2)

cart1 = ShoppingCart()
cart2 = ShoppingCart()

# adding products to cart operations
cart1.add_to_cart(product1, 2)
cart1.add_to_cart(product2, 1)
cart2.add_to_cart(product3, 3)
cart2.add_to_cart(product1, 1)

# displaying cart content and calculating totals
print("\nCart 1 Contents:")
cart1.display_cart()
print(f"Total: Shs{cart1.calculate_total():.2f}")

print("\nCart 2 Contents:")
cart2.display_cart()
print(f"Total: Shs{cart2.calculate_total():.2f}")

#removing items from cart
cart1.remove_from_cart(product1)
cart2.remove_from_cart(product3)

#displaying updated cart contents and calculate total
print("\nUpdated Cart 1 Contents:")
cart1.display_cart()
print(f"Total: Shs{cart1.calculate_total():.2f}")

print("\nUpdated Cart 2 Contents:")
cart2.display_cart()
print(f"Total: Shs{cart2.calculate_total():.2f}")